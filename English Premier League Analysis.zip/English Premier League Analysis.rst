.. code:: ipython3

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sn 

.. code:: ipython3

    football=pd.read_csv('https://andybek.com/pandas-soccer')

.. code:: ipython3

    football.head(10)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alexis Sanchez</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>LW</td>
          <td>1</td>
          <td>65.0</td>
          <td>4329</td>
          <td>12.0</td>
          <td>17.10%</td>
          <td>264</td>
          <td>3</td>
          <td>Chile</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Mesut Ozil</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>AM</td>
          <td>1</td>
          <td>50.0</td>
          <td>4395</td>
          <td>9.5</td>
          <td>5.60%</td>
          <td>167</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Petr Cech</td>
          <td>Arsenal</td>
          <td>35</td>
          <td>GK</td>
          <td>4</td>
          <td>7.0</td>
          <td>1529</td>
          <td>5.5</td>
          <td>5.90%</td>
          <td>134</td>
          <td>2</td>
          <td>Czech Republic</td>
          <td>0</td>
          <td>6</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Theo Walcott</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>RW</td>
          <td>1</td>
          <td>20.0</td>
          <td>2393</td>
          <td>7.5</td>
          <td>1.50%</td>
          <td>122</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Laurent Koscielny</td>
          <td>Arsenal</td>
          <td>31</td>
          <td>CB</td>
          <td>3</td>
          <td>22.0</td>
          <td>912</td>
          <td>6.0</td>
          <td>0.70%</td>
          <td>121</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Hector Bellerin</td>
          <td>Arsenal</td>
          <td>22</td>
          <td>RB</td>
          <td>3</td>
          <td>30.0</td>
          <td>1675</td>
          <td>6.0</td>
          <td>13.70%</td>
          <td>119</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>6</th>
          <td>Olivier Giroud</td>
          <td>Arsenal</td>
          <td>30</td>
          <td>CF</td>
          <td>1</td>
          <td>22.0</td>
          <td>2230</td>
          <td>8.5</td>
          <td>2.50%</td>
          <td>116</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Nacho Monreal</td>
          <td>Arsenal</td>
          <td>31</td>
          <td>LB</td>
          <td>3</td>
          <td>13.0</td>
          <td>555</td>
          <td>5.5</td>
          <td>4.70%</td>
          <td>115</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Shkodran Mustafi</td>
          <td>Arsenal</td>
          <td>25</td>
          <td>CB</td>
          <td>3</td>
          <td>30.0</td>
          <td>1877</td>
          <td>5.5</td>
          <td>4.00%</td>
          <td>90</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>3</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>9</th>
          <td>Alex Iwobi</td>
          <td>Arsenal</td>
          <td>21</td>
          <td>LW</td>
          <td>1</td>
          <td>10.0</td>
          <td>1812</td>
          <td>5.5</td>
          <td>1.00%</td>
          <td>89</td>
          <td>4</td>
          <td>Nigeria</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    football.info(memory_usage='deep')


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 465 entries, 0 to 464
    Data columns (total 17 columns):
     #   Column        Non-Null Count  Dtype  
    ---  ------        --------------  -----  
     0   name          465 non-null    object 
     1   club          465 non-null    object 
     2   age           465 non-null    int64  
     3   position      464 non-null    object 
     4   position_cat  465 non-null    int64  
     5   market_value  462 non-null    float64
     6   page_views    465 non-null    int64  
     7   fpl_value     465 non-null    float64
     8   fpl_sel       465 non-null    object 
     9   fpl_points    465 non-null    int64  
     10  region        465 non-null    int64  
     11  nationality   465 non-null    object 
     12  new_foreign   465 non-null    int64  
     13  age_cat       465 non-null    int64  
     14  club_id       465 non-null    int64  
     15  big_club      465 non-null    int64  
     16  new_signing   465 non-null    int64  
    dtypes: float64(2), int64(10), object(5)
    memory usage: 172.5 KB
    

.. code:: ipython3

    football[football.duplicated()]




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>11</th>
          <td>Granit Xhaka</td>
          <td>Arsenal</td>
          <td>24</td>
          <td>DM</td>
          <td>2</td>
          <td>35.0</td>
          <td>1815</td>
          <td>5.5</td>
          <td>2.00%</td>
          <td>85</td>
          <td>2</td>
          <td>Switzerland</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>13</th>
          <td>Alex Oxlade-Chamberlain</td>
          <td>Arsenal</td>
          <td>23</td>
          <td>RM</td>
          <td>2</td>
          <td>22.0</td>
          <td>1519</td>
          <td>6.0</td>
          <td>1.80%</td>
          <td>83</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>23</th>
          <td>Alex Oxlade-Chamberlain</td>
          <td>Arsenal</td>
          <td>23</td>
          <td>RM</td>
          <td>2</td>
          <td>22.0</td>
          <td>1519</td>
          <td>6.0</td>
          <td>1.80%</td>
          <td>83</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    football=football.drop_duplicates()

.. code:: ipython3

    f1=football['club'].value_counts(sort=False) ##Teams and there respective players

.. code:: ipython3

    f1




.. parsed-literal::

    club
    Arsenal              32
    Bournemouth          24
    Brighton+and+Hove    22
    Burnley              18
    Chelsea              20
    Crystal+Palace       21
    Everton              28
    Huddersfield         28
    Leicester+City       24
    Liverpool            27
    Manchester+City      20
    Manchester+United    25
    Newcastle+United     21
    Southampton          23
    Stoke+City           22
    Swansea              25
    Tottenham            20
    Watford              24
    West+Brom            19
    West+Ham             22
    Name: count, dtype: int64



.. code:: ipython3

    f1.plot(kind='bar',color='Blue',figsize=(10,8));
    f1.plot(kind='bar',color='Blue',figsize=(10,8)).set_xlabel('Clubs');
    f1.plot(kind='bar',color='Blue',figsize=(10,8)).set_ylabel('Total number of players');



.. image:: output_8_0.png


.. code:: ipython3

    football.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>age</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>462.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
          <td>465.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>26.776344</td>
          <td>2.178495</td>
          <td>11.125649</td>
          <td>771.546237</td>
          <td>5.450538</td>
          <td>57.544086</td>
          <td>1.989247</td>
          <td>0.034409</td>
          <td>3.195699</td>
          <td>10.253763</td>
          <td>0.309677</td>
          <td>0.144086</td>
        </tr>
        <tr>
          <th>std</th>
          <td>3.956863</td>
          <td>0.995880</td>
          <td>12.312959</td>
          <td>931.631982</td>
          <td>1.341370</td>
          <td>52.941969</td>
          <td>0.954737</td>
          <td>0.182473</td>
          <td>1.279136</td>
          <td>5.766665</td>
          <td>0.462859</td>
          <td>0.351555</td>
        </tr>
        <tr>
          <th>min</th>
          <td>17.000000</td>
          <td>1.000000</td>
          <td>0.050000</td>
          <td>3.000000</td>
          <td>4.000000</td>
          <td>0.000000</td>
          <td>1.000000</td>
          <td>0.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>24.000000</td>
          <td>1.000000</td>
          <td>3.000000</td>
          <td>221.000000</td>
          <td>4.500000</td>
          <td>5.000000</td>
          <td>1.000000</td>
          <td>0.000000</td>
          <td>2.000000</td>
          <td>6.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>27.000000</td>
          <td>2.000000</td>
          <td>7.000000</td>
          <td>461.000000</td>
          <td>5.000000</td>
          <td>51.000000</td>
          <td>2.000000</td>
          <td>0.000000</td>
          <td>3.000000</td>
          <td>10.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>29.000000</td>
          <td>3.000000</td>
          <td>15.000000</td>
          <td>935.000000</td>
          <td>6.000000</td>
          <td>94.000000</td>
          <td>2.000000</td>
          <td>0.000000</td>
          <td>4.000000</td>
          <td>15.000000</td>
          <td>1.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>38.000000</td>
          <td>4.000000</td>
          <td>75.000000</td>
          <td>7664.000000</td>
          <td>12.500000</td>
          <td>264.000000</td>
          <td>4.000000</td>
          <td>1.000000</td>
          <td>6.000000</td>
          <td>20.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    football.shape ## duplicated removed 




.. parsed-literal::

    (462, 17)



.. code:: ipython3

    ## each club and its most expensive player 
    football.loc[:,['name','club','market_value']].groupby('club').max()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>market_value</th>
        </tr>
        <tr>
          <th>club</th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Arsenal</th>
          <td>Theo Walcott</td>
          <td>65.0</td>
        </tr>
        <tr>
          <th>Bournemouth</th>
          <td>Tyrone Mings</td>
          <td>10.0</td>
        </tr>
        <tr>
          <th>Brighton+and+Hove</th>
          <td>Uwe Hunemeier</td>
          <td>8.0</td>
        </tr>
        <tr>
          <th>Burnley</th>
          <td>Tom Heaton</td>
          <td>10.0</td>
        </tr>
        <tr>
          <th>Chelsea</th>
          <td>Willy Caballero</td>
          <td>75.0</td>
        </tr>
        <tr>
          <th>Crystal+Palace</th>
          <td>Yohan Cabaye</td>
          <td>28.0</td>
        </tr>
        <tr>
          <th>Everton</th>
          <td>Yannick Bolasie</td>
          <td>25.0</td>
        </tr>
        <tr>
          <th>Huddersfield</th>
          <td>Tommy Smith</td>
          <td>7.0</td>
        </tr>
        <tr>
          <th>Leicester+City</th>
          <td>Yohan Benalouane</td>
          <td>30.0</td>
        </tr>
        <tr>
          <th>Liverpool</th>
          <td>Trent Alexander-Arnold</td>
          <td>45.0</td>
        </tr>
        <tr>
          <th>Manchester+City</th>
          <td>Yaya Toure</td>
          <td>65.0</td>
        </tr>
        <tr>
          <th>Manchester+United</th>
          <td>Victor Lindelof</td>
          <td>75.0</td>
        </tr>
        <tr>
          <th>Newcastle+United</th>
          <td>Siem de Jong</td>
          <td>11.0</td>
        </tr>
        <tr>
          <th>Southampton</th>
          <td>Virgil van Dijk</td>
          <td>30.0</td>
        </tr>
        <tr>
          <th>Stoke+City</th>
          <td>Xherdan Shaqiri</td>
          <td>15.0</td>
        </tr>
        <tr>
          <th>Swansea</th>
          <td>Åukasz FabiaÅ„ski</td>
          <td>25.0</td>
        </tr>
        <tr>
          <th>Tottenham</th>
          <td>Vincent Janssen</td>
          <td>60.0</td>
        </tr>
        <tr>
          <th>Watford</th>
          <td>Ã‰tienne Capoue</td>
          <td>15.0</td>
        </tr>
        <tr>
          <th>West+Brom</th>
          <td>Sam Field</td>
          <td>15.0</td>
        </tr>
        <tr>
          <th>West+Ham</th>
          <td>Winston Reid</td>
          <td>18.0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    def rated(x):
        if x<400:
          return('Relatively Unkown')
        elif x<800:
          return('Kind of Popular')
        elif x<2800:
          return('Popular')
        else:
          return('Super Popular')

.. code:: ipython3

    football.loc[:,'page_views'].apply(rated)




.. parsed-literal::

    0          Super Popular
    1          Super Popular
    2                Popular
    3                Popular
    4                Popular
                 ...        
    460    Relatively Unkown
    461    Relatively Unkown
    462    Relatively Unkown
    463      Kind of Popular
    464    Relatively Unkown
    Name: page_views, Length: 462, dtype: object



.. code:: ipython3

    football.loc[:,'page_views'].apply(rated).value_counts(sort=False).plot(kind='pie',figsize=(4,6)).set_ylabel('Page Views');



.. image:: output_14_0.png


.. code:: ipython3

    football['Popularity']=football.loc[:,'page_views'].apply(rated)

.. code:: ipython3

    football.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
          <th>Popularity</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alexis Sanchez</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>LW</td>
          <td>1</td>
          <td>65.0</td>
          <td>4329</td>
          <td>12.0</td>
          <td>17.10%</td>
          <td>264</td>
          <td>3</td>
          <td>Chile</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Mesut Ozil</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>AM</td>
          <td>1</td>
          <td>50.0</td>
          <td>4395</td>
          <td>9.5</td>
          <td>5.60%</td>
          <td>167</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Petr Cech</td>
          <td>Arsenal</td>
          <td>35</td>
          <td>GK</td>
          <td>4</td>
          <td>7.0</td>
          <td>1529</td>
          <td>5.5</td>
          <td>5.90%</td>
          <td>134</td>
          <td>2</td>
          <td>Czech Republic</td>
          <td>0</td>
          <td>6</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Theo Walcott</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>RW</td>
          <td>1</td>
          <td>20.0</td>
          <td>2393</td>
          <td>7.5</td>
          <td>1.50%</td>
          <td>122</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Laurent Koscielny</td>
          <td>Arsenal</td>
          <td>31</td>
          <td>CB</td>
          <td>3</td>
          <td>22.0</td>
          <td>912</td>
          <td>6.0</td>
          <td>0.70%</td>
          <td>121</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    ##players most famous according to fantasy league too 
    football.position.value_counts(sort=False)




.. parsed-literal::

    position
    LW    36
    AM    17
    GK    42
    RW    32
    CB    85
    RB    34
    CF    61
    LB    35
    DM    36
    RM     5
    CM    63
    SS     7
    LM     8
    Name: count, dtype: int64



.. code:: ipython3

    ## which team has the most defenders
    football.loc[:,['position','club']][football.position.isin(['LB','CB','RB'])].groupby('club').count().sort_values(by='position',ascending=False)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>position</th>
        </tr>
        <tr>
          <th>club</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>Arsenal</th>
          <td>10</td>
        </tr>
        <tr>
          <th>Manchester+United</th>
          <td>10</td>
        </tr>
        <tr>
          <th>Everton</th>
          <td>10</td>
        </tr>
        <tr>
          <th>Huddersfield</th>
          <td>10</td>
        </tr>
        <tr>
          <th>Watford</th>
          <td>9</td>
        </tr>
        <tr>
          <th>Liverpool</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Southampton</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Newcastle+United</th>
          <td>8</td>
        </tr>
        <tr>
          <th>West+Ham</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Leicester+City</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Crystal+Palace</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Brighton+and+Hove</th>
          <td>8</td>
        </tr>
        <tr>
          <th>Bournemouth</th>
          <td>7</td>
        </tr>
        <tr>
          <th>Chelsea</th>
          <td>7</td>
        </tr>
        <tr>
          <th>Stoke+City</th>
          <td>7</td>
        </tr>
        <tr>
          <th>Swansea</th>
          <td>7</td>
        </tr>
        <tr>
          <th>Tottenham</th>
          <td>6</td>
        </tr>
        <tr>
          <th>Burnley</th>
          <td>5</td>
        </tr>
        <tr>
          <th>West+Brom</th>
          <td>5</td>
        </tr>
        <tr>
          <th>Manchester+City</th>
          <td>5</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    ##players with market value and fpl value 2* of its mean fall under which category of popularity,if new player then also show 
    v=football.loc[:,'market_value'] > 2*football.loc[:,'market_value'].mean()
    o=football.loc[:,'fpl_value'] > 2*football.loc[:,'fpl_value'].mean()

.. code:: ipython3

    football[v & o | football.loc[:,'new_signing']==1].sort_values('Popularity')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
          <th>Popularity</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>463</th>
          <td>Ashley Fletcher</td>
          <td>West+Ham</td>
          <td>21</td>
          <td>CF</td>
          <td>1</td>
          <td>1.0</td>
          <td>412</td>
          <td>4.5</td>
          <td>5.90%</td>
          <td>16</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>1</td>
          <td>20</td>
          <td>0</td>
          <td>1</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>412</th>
          <td>Stefano Okaka</td>
          <td>Watford</td>
          <td>27</td>
          <td>CF</td>
          <td>1</td>
          <td>6.0</td>
          <td>708</td>
          <td>5.5</td>
          <td>0.20%</td>
          <td>43</td>
          <td>2</td>
          <td>Italy</td>
          <td>0</td>
          <td>3</td>
          <td>18</td>
          <td>0</td>
          <td>1</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>398</th>
          <td>Georges-Kevin N%27Koudou</td>
          <td>Tottenham</td>
          <td>22</td>
          <td>LW</td>
          <td>1</td>
          <td>7.0</td>
          <td>510</td>
          <td>5.5</td>
          <td>0.10%</td>
          <td>8</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>2</td>
          <td>17</td>
          <td>1</td>
          <td>1</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>426</th>
          <td>Matt Phillips</td>
          <td>West+Brom</td>
          <td>26</td>
          <td>RW</td>
          <td>1</td>
          <td>9.0</td>
          <td>454</td>
          <td>6.0</td>
          <td>5.60%</td>
          <td>115</td>
          <td>2</td>
          <td>Scotland</td>
          <td>0</td>
          <td>3</td>
          <td>19</td>
          <td>0</td>
          <td>1</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>359</th>
          <td>Alfie Mawson</td>
          <td>Swansea</td>
          <td>23</td>
          <td>CB</td>
          <td>3</td>
          <td>6.0</td>
          <td>509</td>
          <td>5.0</td>
          <td>1.80%</td>
          <td>94</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>16</td>
          <td>0</td>
          <td>1</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>219</th>
          <td>Sadio Mane</td>
          <td>Liverpool</td>
          <td>25</td>
          <td>LW</td>
          <td>1</td>
          <td>40.0</td>
          <td>3219</td>
          <td>9.5</td>
          <td>5.30%</td>
          <td>156</td>
          <td>4</td>
          <td>Senegal</td>
          <td>0</td>
          <td>3</td>
          <td>10</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>108</th>
          <td>N%27Golo Kante</td>
          <td>Chelsea</td>
          <td>26</td>
          <td>DM</td>
          <td>2</td>
          <td>50.0</td>
          <td>4042</td>
          <td>5.0</td>
          <td>13.80%</td>
          <td>83</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>3</td>
          <td>5</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>99</th>
          <td>Marcos Alonso Mendoza</td>
          <td>Chelsea</td>
          <td>26</td>
          <td>LB</td>
          <td>3</td>
          <td>25.0</td>
          <td>3069</td>
          <td>7.0</td>
          <td>12.40%</td>
          <td>177</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>3</td>
          <td>5</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>381</th>
          <td>Harry Kane</td>
          <td>Tottenham</td>
          <td>23</td>
          <td>CF</td>
          <td>1</td>
          <td>60.0</td>
          <td>4161</td>
          <td>12.5</td>
          <td>35.10%</td>
          <td>224</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>17</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>267</th>
          <td>Paul Pogba</td>
          <td>Manchester+United</td>
          <td>24</td>
          <td>CM</td>
          <td>2</td>
          <td>75.0</td>
          <td>7435</td>
          <td>8.0</td>
          <td>19.50%</td>
          <td>115</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>2</td>
          <td>12</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
      </tbody>
    </table>
    <p>71 rows × 18 columns</p>
    </div>



.. code:: ipython3

    football.region.value_counts(sort=False)




.. parsed-literal::

    region
    3     41
    2    209
    1    156
    4     56
    Name: count, dtype: int64



.. code:: ipython3

    ## see which region is doing most in terms of market value and fpl points
    football.loc[:,['club','market_value','fpl_points','region']].groupby('region').mean(numeric_only=True)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>market_value</th>
          <th>fpl_points</th>
        </tr>
        <tr>
          <th>region</th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>1</th>
          <td>8.482372</td>
          <td>55.051282</td>
        </tr>
        <tr>
          <th>2</th>
          <td>12.219175</td>
          <td>59.588517</td>
        </tr>
        <tr>
          <th>3</th>
          <td>14.704878</td>
          <td>65.146341</td>
        </tr>
        <tr>
          <th>4</th>
          <td>11.031250</td>
          <td>49.892857</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    f2=football.loc[:,['club','market_value','fpl_points','region']].groupby('region').mean(numeric_only=True)
    f2.plot(kind='pie',subplots=True,figsize=(10,8));



.. image:: output_23_0.png


.. code:: ipython3

    ##what percentage of players are English in the league
    len(football.nationality[football.nationality == 'England'])/len(football.nationality[football.nationality != 'England'])*100




.. parsed-literal::

    50.98039215686274



.. code:: ipython3

    ##multiindex use too 
    football.nlargest(1,columns='age')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
          <th>Popularity</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>136</th>
          <td>Julian Speroni</td>
          <td>Crystal+Palace</td>
          <td>38</td>
          <td>GK</td>
          <td>4</td>
          <td>0.25</td>
          <td>188</td>
          <td>4.0</td>
          <td>2.00%</td>
          <td>0</td>
          <td>3</td>
          <td>Argentina</td>
          <td>0</td>
          <td>6</td>
          <td>6</td>
          <td>0</td>
          <td>0</td>
          <td>Relatively Unkown</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    football.head(14)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
          <th>Popularity</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alexis Sanchez</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>LW</td>
          <td>1</td>
          <td>65.0</td>
          <td>4329</td>
          <td>12.0</td>
          <td>17.10%</td>
          <td>264</td>
          <td>3</td>
          <td>Chile</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Mesut Ozil</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>AM</td>
          <td>1</td>
          <td>50.0</td>
          <td>4395</td>
          <td>9.5</td>
          <td>5.60%</td>
          <td>167</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Petr Cech</td>
          <td>Arsenal</td>
          <td>35</td>
          <td>GK</td>
          <td>4</td>
          <td>7.0</td>
          <td>1529</td>
          <td>5.5</td>
          <td>5.90%</td>
          <td>134</td>
          <td>2</td>
          <td>Czech Republic</td>
          <td>0</td>
          <td>6</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Theo Walcott</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>RW</td>
          <td>1</td>
          <td>20.0</td>
          <td>2393</td>
          <td>7.5</td>
          <td>1.50%</td>
          <td>122</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Laurent Koscielny</td>
          <td>Arsenal</td>
          <td>31</td>
          <td>CB</td>
          <td>3</td>
          <td>22.0</td>
          <td>912</td>
          <td>6.0</td>
          <td>0.70%</td>
          <td>121</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Hector Bellerin</td>
          <td>Arsenal</td>
          <td>22</td>
          <td>RB</td>
          <td>3</td>
          <td>30.0</td>
          <td>1675</td>
          <td>6.0</td>
          <td>13.70%</td>
          <td>119</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>6</th>
          <td>Olivier Giroud</td>
          <td>Arsenal</td>
          <td>30</td>
          <td>CF</td>
          <td>1</td>
          <td>22.0</td>
          <td>2230</td>
          <td>8.5</td>
          <td>2.50%</td>
          <td>116</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>7</th>
          <td>Nacho Monreal</td>
          <td>Arsenal</td>
          <td>31</td>
          <td>LB</td>
          <td>3</td>
          <td>13.0</td>
          <td>555</td>
          <td>5.5</td>
          <td>4.70%</td>
          <td>115</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>8</th>
          <td>Shkodran Mustafi</td>
          <td>Arsenal</td>
          <td>25</td>
          <td>CB</td>
          <td>3</td>
          <td>30.0</td>
          <td>1877</td>
          <td>5.5</td>
          <td>4.00%</td>
          <td>90</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>3</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>9</th>
          <td>Alex Iwobi</td>
          <td>Arsenal</td>
          <td>21</td>
          <td>LW</td>
          <td>1</td>
          <td>10.0</td>
          <td>1812</td>
          <td>5.5</td>
          <td>1.00%</td>
          <td>89</td>
          <td>4</td>
          <td>Nigeria</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>10</th>
          <td>Granit Xhaka</td>
          <td>Arsenal</td>
          <td>24</td>
          <td>DM</td>
          <td>2</td>
          <td>35.0</td>
          <td>1815</td>
          <td>5.5</td>
          <td>2.00%</td>
          <td>85</td>
          <td>2</td>
          <td>Switzerland</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>12</th>
          <td>Alex Oxlade-Chamberlain</td>
          <td>Arsenal</td>
          <td>23</td>
          <td>RM</td>
          <td>2</td>
          <td>22.0</td>
          <td>1519</td>
          <td>6.0</td>
          <td>1.80%</td>
          <td>83</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>14</th>
          <td>Jack Wilshere</td>
          <td>Arsenal</td>
          <td>25</td>
          <td>CM</td>
          <td>2</td>
          <td>18.0</td>
          <td>1759</td>
          <td>5.5</td>
          <td>0.00%</td>
          <td>61</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>3</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>15</th>
          <td>Aaron Ramsey</td>
          <td>Arsenal</td>
          <td>26</td>
          <td>CM</td>
          <td>2</td>
          <td>35.0</td>
          <td>1040</td>
          <td>7.0</td>
          <td>5.10%</td>
          <td>56</td>
          <td>1</td>
          <td>Wales</td>
          <td>0</td>
          <td>3</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    football[['name','market_value']].nlargest(1,'market_value')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>market_value</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>96</th>
          <td>Eden Hazard</td>
          <td>75.0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    l=football.loc[:,'fpl_sel'].replace('%','',regex=True).astype(float)

.. code:: ipython3

    y=football.loc[:,'market_value'] > football.loc[:,'market_value'].mean() 

.. code:: ipython3

    football['fpl_sel']=l

.. code:: ipython3

    l.mean()




.. parsed-literal::

    3.2415584415584413



.. code:: ipython3

    football[y & (l>5)].sort_values(['market_value'],ascending=[False]) ## these are the players who are playing better since coming from there last team 




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
          <th>Popularity</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>267</th>
          <td>Paul Pogba</td>
          <td>Manchester+United</td>
          <td>24</td>
          <td>CM</td>
          <td>2</td>
          <td>75.0</td>
          <td>7435</td>
          <td>8.0</td>
          <td>19.5</td>
          <td>115</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>2</td>
          <td>12</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>0</th>
          <td>Alexis Sanchez</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>LW</td>
          <td>1</td>
          <td>65.0</td>
          <td>4329</td>
          <td>12.0</td>
          <td>17.1</td>
          <td>264</td>
          <td>3</td>
          <td>Chile</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>245</th>
          <td>Sergio Aguero</td>
          <td>Manchester+City</td>
          <td>29</td>
          <td>CF</td>
          <td>1</td>
          <td>65.0</td>
          <td>4046</td>
          <td>11.5</td>
          <td>9.7</td>
          <td>175</td>
          <td>3</td>
          <td>Argentina</td>
          <td>0</td>
          <td>4</td>
          <td>11</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>244</th>
          <td>Kevin De Bruyne</td>
          <td>Manchester+City</td>
          <td>26</td>
          <td>AM</td>
          <td>1</td>
          <td>65.0</td>
          <td>2252</td>
          <td>10.0</td>
          <td>17.5</td>
          <td>199</td>
          <td>2</td>
          <td>Belgium</td>
          <td>0</td>
          <td>3</td>
          <td>11</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>381</th>
          <td>Harry Kane</td>
          <td>Tottenham</td>
          <td>23</td>
          <td>CF</td>
          <td>1</td>
          <td>60.0</td>
          <td>4161</td>
          <td>12.5</td>
          <td>35.1</td>
          <td>224</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>17</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>108</th>
          <td>N%27Golo Kante</td>
          <td>Chelsea</td>
          <td>26</td>
          <td>DM</td>
          <td>2</td>
          <td>50.0</td>
          <td>4042</td>
          <td>5.0</td>
          <td>13.8</td>
          <td>83</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>3</td>
          <td>5</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>264</th>
          <td>Romelu Lukaku</td>
          <td>Manchester+United</td>
          <td>24</td>
          <td>CF</td>
          <td>1</td>
          <td>50.0</td>
          <td>3727</td>
          <td>11.5</td>
          <td>45.0</td>
          <td>221</td>
          <td>2</td>
          <td>Belgium</td>
          <td>0</td>
          <td>2</td>
          <td>12</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Mesut Ozil</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>AM</td>
          <td>1</td>
          <td>50.0</td>
          <td>4395</td>
          <td>9.5</td>
          <td>5.6</td>
          <td>167</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>380</th>
          <td>Dele Alli</td>
          <td>Tottenham</td>
          <td>21</td>
          <td>CM</td>
          <td>2</td>
          <td>45.0</td>
          <td>4626</td>
          <td>9.5</td>
          <td>38.6</td>
          <td>225</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>1</td>
          <td>17</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>218</th>
          <td>Philippe Coutinho</td>
          <td>Liverpool</td>
          <td>25</td>
          <td>AM</td>
          <td>1</td>
          <td>45.0</td>
          <td>2958</td>
          <td>9.0</td>
          <td>30.8</td>
          <td>171</td>
          <td>3</td>
          <td>Brazil</td>
          <td>0</td>
          <td>3</td>
          <td>10</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>102</th>
          <td>Thibaut Courtois</td>
          <td>Chelsea</td>
          <td>25</td>
          <td>GK</td>
          <td>4</td>
          <td>40.0</td>
          <td>1260</td>
          <td>5.5</td>
          <td>18.5</td>
          <td>141</td>
          <td>2</td>
          <td>Belgium</td>
          <td>0</td>
          <td>3</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>382</th>
          <td>Christian Eriksen</td>
          <td>Tottenham</td>
          <td>25</td>
          <td>AM</td>
          <td>1</td>
          <td>40.0</td>
          <td>1130</td>
          <td>9.5</td>
          <td>12.0</td>
          <td>218</td>
          <td>2</td>
          <td>Denmark</td>
          <td>0</td>
          <td>3</td>
          <td>17</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>31</th>
          <td>Alexandre Lacazette</td>
          <td>Arsenal</td>
          <td>26</td>
          <td>CF</td>
          <td>1</td>
          <td>40.0</td>
          <td>1183</td>
          <td>10.5</td>
          <td>26.5</td>
          <td>0</td>
          <td>2</td>
          <td>France</td>
          <td>1</td>
          <td>3</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>265</th>
          <td>David de Gea</td>
          <td>Manchester+United</td>
          <td>26</td>
          <td>GK</td>
          <td>4</td>
          <td>40.0</td>
          <td>2126</td>
          <td>5.5</td>
          <td>26.1</td>
          <td>136</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>3</td>
          <td>12</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>219</th>
          <td>Sadio Mane</td>
          <td>Liverpool</td>
          <td>25</td>
          <td>LW</td>
          <td>1</td>
          <td>40.0</td>
          <td>3219</td>
          <td>9.5</td>
          <td>5.3</td>
          <td>156</td>
          <td>4</td>
          <td>Senegal</td>
          <td>0</td>
          <td>3</td>
          <td>10</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>217</th>
          <td>Roberto Firmino</td>
          <td>Liverpool</td>
          <td>25</td>
          <td>SS</td>
          <td>1</td>
          <td>38.0</td>
          <td>2196</td>
          <td>8.5</td>
          <td>20.3</td>
          <td>180</td>
          <td>3</td>
          <td>Brazil</td>
          <td>0</td>
          <td>3</td>
          <td>10</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>249</th>
          <td>Leroy Sane</td>
          <td>Manchester+City</td>
          <td>21</td>
          <td>LW</td>
          <td>1</td>
          <td>35.0</td>
          <td>2302</td>
          <td>8.5</td>
          <td>8.8</td>
          <td>105</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>1</td>
          <td>11</td>
          <td>1</td>
          <td>1</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>104</th>
          <td>Cesc Fabregas</td>
          <td>Chelsea</td>
          <td>30</td>
          <td>CM</td>
          <td>2</td>
          <td>35.0</td>
          <td>2378</td>
          <td>7.0</td>
          <td>7.5</td>
          <td>121</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>4</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>386</th>
          <td>Toby Alderweireld</td>
          <td>Tottenham</td>
          <td>28</td>
          <td>CB</td>
          <td>3</td>
          <td>35.0</td>
          <td>756</td>
          <td>6.0</td>
          <td>13.3</td>
          <td>120</td>
          <td>2</td>
          <td>Belgium</td>
          <td>0</td>
          <td>4</td>
          <td>17</td>
          <td>1</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>241</th>
          <td>Mohamed Salah</td>
          <td>Liverpool</td>
          <td>25</td>
          <td>RW</td>
          <td>1</td>
          <td>35.0</td>
          <td>1117</td>
          <td>9.0</td>
          <td>12.4</td>
          <td>0</td>
          <td>4</td>
          <td>Egypt</td>
          <td>1</td>
          <td>3</td>
          <td>10</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>15</th>
          <td>Aaron Ramsey</td>
          <td>Arsenal</td>
          <td>26</td>
          <td>CM</td>
          <td>2</td>
          <td>35.0</td>
          <td>1040</td>
          <td>7.0</td>
          <td>5.1</td>
          <td>56</td>
          <td>1</td>
          <td>Wales</td>
          <td>0</td>
          <td>3</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>105</th>
          <td>Willian</td>
          <td>Chelsea</td>
          <td>28</td>
          <td>RW</td>
          <td>1</td>
          <td>32.0</td>
          <td>1165</td>
          <td>7.0</td>
          <td>9.0</td>
          <td>114</td>
          <td>3</td>
          <td>Brazil</td>
          <td>0</td>
          <td>4</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>100</th>
          <td>Cesar Azpilicueta</td>
          <td>Chelsea</td>
          <td>27</td>
          <td>RB</td>
          <td>3</td>
          <td>30.0</td>
          <td>869</td>
          <td>6.5</td>
          <td>12.3</td>
          <td>170</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>3</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>247</th>
          <td>Kyle Walker</td>
          <td>Manchester+City</td>
          <td>27</td>
          <td>RB</td>
          <td>3</td>
          <td>30.0</td>
          <td>1008</td>
          <td>6.5</td>
          <td>18.5</td>
          <td>142</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>3</td>
          <td>11</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>103</th>
          <td>David Luiz</td>
          <td>Chelsea</td>
          <td>30</td>
          <td>CB</td>
          <td>3</td>
          <td>30.0</td>
          <td>2745</td>
          <td>6.0</td>
          <td>20.3</td>
          <td>132</td>
          <td>3</td>
          <td>Brazil</td>
          <td>0</td>
          <td>4</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>5</th>
          <td>Hector Bellerin</td>
          <td>Arsenal</td>
          <td>22</td>
          <td>RB</td>
          <td>3</td>
          <td>30.0</td>
          <td>1675</td>
          <td>6.0</td>
          <td>13.7</td>
          <td>119</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>255</th>
          <td>Gabriel Jesus</td>
          <td>Manchester+City</td>
          <td>20</td>
          <td>CF</td>
          <td>1</td>
          <td>30.0</td>
          <td>4254</td>
          <td>10.5</td>
          <td>15.2</td>
          <td>67</td>
          <td>3</td>
          <td>Brazil</td>
          <td>0</td>
          <td>1</td>
          <td>11</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>268</th>
          <td>Eric Bailly</td>
          <td>Manchester+United</td>
          <td>23</td>
          <td>CB</td>
          <td>3</td>
          <td>30.0</td>
          <td>1588</td>
          <td>6.0</td>
          <td>10.2</td>
          <td>105</td>
          <td>4</td>
          <td>Cote d'Ivoire</td>
          <td>0</td>
          <td>2</td>
          <td>12</td>
          <td>1</td>
          <td>1</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>271</th>
          <td>Ander Herrera</td>
          <td>Manchester+United</td>
          <td>27</td>
          <td>CM</td>
          <td>2</td>
          <td>30.0</td>
          <td>1603</td>
          <td>5.5</td>
          <td>7.7</td>
          <td>97</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>3</td>
          <td>12</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>117</th>
          <td>Christian Benteke</td>
          <td>Crystal+Palace</td>
          <td>26</td>
          <td>CF</td>
          <td>1</td>
          <td>28.0</td>
          <td>1661</td>
          <td>8.0</td>
          <td>10.5</td>
          <td>136</td>
          <td>2</td>
          <td>Belgium</td>
          <td>0</td>
          <td>3</td>
          <td>6</td>
          <td>0</td>
          <td>1</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>101</th>
          <td>Pedro</td>
          <td>Chelsea</td>
          <td>29</td>
          <td>RW</td>
          <td>1</td>
          <td>28.0</td>
          <td>1500</td>
          <td>8.0</td>
          <td>7.8</td>
          <td>162</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>4</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>385</th>
          <td>Jan Vertonghen</td>
          <td>Tottenham</td>
          <td>30</td>
          <td>CB</td>
          <td>3</td>
          <td>28.0</td>
          <td>511</td>
          <td>6.0</td>
          <td>9.0</td>
          <td>126</td>
          <td>2</td>
          <td>Belgium</td>
          <td>0</td>
          <td>4</td>
          <td>17</td>
          <td>1</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>220</th>
          <td>Georginio Wijnaldum</td>
          <td>Liverpool</td>
          <td>26</td>
          <td>CM</td>
          <td>2</td>
          <td>28.0</td>
          <td>1280</td>
          <td>7.0</td>
          <td>7.1</td>
          <td>149</td>
          <td>2</td>
          <td>Netherlands</td>
          <td>0</td>
          <td>3</td>
          <td>10</td>
          <td>1</td>
          <td>1</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>355</th>
          <td>Gylfi Sigurdsson</td>
          <td>Swansea</td>
          <td>27</td>
          <td>AM</td>
          <td>1</td>
          <td>25.0</td>
          <td>861</td>
          <td>8.5</td>
          <td>8.7</td>
          <td>181</td>
          <td>2</td>
          <td>Iceland</td>
          <td>0</td>
          <td>3</td>
          <td>16</td>
          <td>0</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>99</th>
          <td>Marcos Alonso Mendoza</td>
          <td>Chelsea</td>
          <td>26</td>
          <td>LB</td>
          <td>3</td>
          <td>25.0</td>
          <td>3069</td>
          <td>7.0</td>
          <td>12.4</td>
          <td>177</td>
          <td>2</td>
          <td>Spain</td>
          <td>0</td>
          <td>3</td>
          <td>5</td>
          <td>1</td>
          <td>1</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>222</th>
          <td>Adam Lallana</td>
          <td>Liverpool</td>
          <td>29</td>
          <td>AM</td>
          <td>1</td>
          <td>25.0</td>
          <td>1808</td>
          <td>7.5</td>
          <td>6.4</td>
          <td>139</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>10</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>114</th>
          <td>Antonio Rudiger</td>
          <td>Chelsea</td>
          <td>24</td>
          <td>CB</td>
          <td>3</td>
          <td>25.0</td>
          <td>454</td>
          <td>6.0</td>
          <td>6.4</td>
          <td>0</td>
          <td>2</td>
          <td>Germany</td>
          <td>1</td>
          <td>2</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>384</th>
          <td>Hugo Lloris</td>
          <td>Tottenham</td>
          <td>30</td>
          <td>GK</td>
          <td>4</td>
          <td>24.0</td>
          <td>847</td>
          <td>5.5</td>
          <td>12.6</td>
          <td>143</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>4</td>
          <td>17</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>257</th>
          <td>Vincent Kompany</td>
          <td>Manchester+City</td>
          <td>31</td>
          <td>CB</td>
          <td>3</td>
          <td>22.0</td>
          <td>935</td>
          <td>6.0</td>
          <td>6.6</td>
          <td>57</td>
          <td>2</td>
          <td>Belgium</td>
          <td>0</td>
          <td>4</td>
          <td>11</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>288</th>
          <td>Victor Lindelof</td>
          <td>Manchester+United</td>
          <td>23</td>
          <td>CB</td>
          <td>3</td>
          <td>22.0</td>
          <td>950</td>
          <td>5.5</td>
          <td>17.0</td>
          <td>0</td>
          <td>2</td>
          <td>Sweden</td>
          <td>1</td>
          <td>2</td>
          <td>12</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>312</th>
          <td>Ryan Bertrand</td>
          <td>Southampton</td>
          <td>27</td>
          <td>LB</td>
          <td>3</td>
          <td>20.0</td>
          <td>578</td>
          <td>5.5</td>
          <td>11.2</td>
          <td>123</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>3</td>
          <td>14</td>
          <td>0</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>142</th>
          <td>Michael Keane</td>
          <td>Everton</td>
          <td>24</td>
          <td>CB</td>
          <td>3</td>
          <td>18.0</td>
          <td>1362</td>
          <td>5.5</td>
          <td>13.1</td>
          <td>113</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>7</td>
          <td>0</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>116</th>
          <td>Wilfried Zaha</td>
          <td>Crystal+Palace</td>
          <td>24</td>
          <td>RW</td>
          <td>1</td>
          <td>18.0</td>
          <td>1709</td>
          <td>7.0</td>
          <td>20.9</td>
          <td>149</td>
          <td>4</td>
          <td>Cote d'Ivoire</td>
          <td>0</td>
          <td>2</td>
          <td>6</td>
          <td>0</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>98</th>
          <td>Gary Cahill</td>
          <td>Chelsea</td>
          <td>31</td>
          <td>CB</td>
          <td>3</td>
          <td>16.0</td>
          <td>1420</td>
          <td>6.5</td>
          <td>12.0</td>
          <td>178</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>5</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>326</th>
          <td>Manolo Gabbiadini</td>
          <td>Southampton</td>
          <td>25</td>
          <td>CF</td>
          <td>1</td>
          <td>15.0</td>
          <td>2012</td>
          <td>7.0</td>
          <td>5.2</td>
          <td>38</td>
          <td>2</td>
          <td>Italy</td>
          <td>0</td>
          <td>3</td>
          <td>14</td>
          <td>0</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>333</th>
          <td>Joe Allen</td>
          <td>Stoke+City</td>
          <td>27</td>
          <td>CM</td>
          <td>2</td>
          <td>15.0</td>
          <td>523</td>
          <td>5.5</td>
          <td>6.0</td>
          <td>118</td>
          <td>2</td>
          <td>Wales</td>
          <td>0</td>
          <td>3</td>
          <td>15</td>
          <td>0</td>
          <td>1</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>226</th>
          <td>Emre Can</td>
          <td>Liverpool</td>
          <td>23</td>
          <td>DM</td>
          <td>2</td>
          <td>15.0</td>
          <td>1253</td>
          <td>5.0</td>
          <td>6.6</td>
          <td>104</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>2</td>
          <td>10</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>314</th>
          <td>Cedric Soares</td>
          <td>Southampton</td>
          <td>25</td>
          <td>RB</td>
          <td>3</td>
          <td>15.0</td>
          <td>338</td>
          <td>5.0</td>
          <td>16.4</td>
          <td>102</td>
          <td>2</td>
          <td>Portugal</td>
          <td>0</td>
          <td>3</td>
          <td>14</td>
          <td>0</td>
          <td>0</td>
          <td>Relatively Unkown</td>
        </tr>
        <tr>
          <th>311</th>
          <td>Nathan Redmond</td>
          <td>Southampton</td>
          <td>23</td>
          <td>RW</td>
          <td>1</td>
          <td>15.0</td>
          <td>706</td>
          <td>6.5</td>
          <td>11.3</td>
          <td>126</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>14</td>
          <td>0</td>
          <td>1</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>310</th>
          <td>Fraser Forster</td>
          <td>Southampton</td>
          <td>29</td>
          <td>GK</td>
          <td>4</td>
          <td>15.0</td>
          <td>548</td>
          <td>5.0</td>
          <td>7.3</td>
          <td>134</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>14</td>
          <td>0</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>147</th>
          <td>Wayne Rooney</td>
          <td>Everton</td>
          <td>31</td>
          <td>SS</td>
          <td>1</td>
          <td>15.0</td>
          <td>7664</td>
          <td>7.5</td>
          <td>20.9</td>
          <td>76</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>7</td>
          <td>0</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>144</th>
          <td>Jordan Pickford</td>
          <td>Everton</td>
          <td>23</td>
          <td>GK</td>
          <td>4</td>
          <td>15.0</td>
          <td>719</td>
          <td>5.0</td>
          <td>14.6</td>
          <td>102</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>2</td>
          <td>7</td>
          <td>0</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>29</th>
          <td>Sead Kolasinac</td>
          <td>Arsenal</td>
          <td>24</td>
          <td>LB</td>
          <td>3</td>
          <td>15.0</td>
          <td>618</td>
          <td>6.0</td>
          <td>6.9</td>
          <td>0</td>
          <td>2</td>
          <td>Bosnia</td>
          <td>1</td>
          <td>2</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>444</th>
          <td>Manuel Lanzini</td>
          <td>West+Ham</td>
          <td>24</td>
          <td>AM</td>
          <td>1</td>
          <td>15.0</td>
          <td>493</td>
          <td>7.0</td>
          <td>7.2</td>
          <td>133</td>
          <td>3</td>
          <td>Argentina</td>
          <td>0</td>
          <td>2</td>
          <td>20</td>
          <td>0</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
        <tr>
          <th>221</th>
          <td>James Milner</td>
          <td>Liverpool</td>
          <td>31</td>
          <td>CM</td>
          <td>2</td>
          <td>12.0</td>
          <td>1824</td>
          <td>6.5</td>
          <td>10.4</td>
          <td>139</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>10</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>138</th>
          <td>Leighton Baines</td>
          <td>Everton</td>
          <td>32</td>
          <td>LB</td>
          <td>3</td>
          <td>12.0</td>
          <td>491</td>
          <td>6.0</td>
          <td>10.0</td>
          <td>135</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>5</td>
          <td>7</td>
          <td>0</td>
          <td>0</td>
          <td>Kind of Popular</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    football.loc[:,['market_value','fpl_value']].transform(lambda x:x*0.91)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>market_value</th>
          <th>fpl_value</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>59.150</td>
          <td>10.920</td>
        </tr>
        <tr>
          <th>1</th>
          <td>45.500</td>
          <td>8.645</td>
        </tr>
        <tr>
          <th>2</th>
          <td>6.370</td>
          <td>5.005</td>
        </tr>
        <tr>
          <th>3</th>
          <td>18.200</td>
          <td>6.825</td>
        </tr>
        <tr>
          <th>4</th>
          <td>20.020</td>
          <td>5.460</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>460</th>
          <td>4.550</td>
          <td>4.095</td>
        </tr>
        <tr>
          <th>461</th>
          <td>6.370</td>
          <td>4.095</td>
        </tr>
        <tr>
          <th>462</th>
          <td>4.095</td>
          <td>4.095</td>
        </tr>
        <tr>
          <th>463</th>
          <td>0.910</td>
          <td>4.095</td>
        </tr>
        <tr>
          <th>464</th>
          <td>9.100</td>
          <td>5.005</td>
        </tr>
      </tbody>
    </table>
    <p>462 rows × 2 columns</p>
    </div>



.. code:: ipython3

    football.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>name</th>
          <th>club</th>
          <th>age</th>
          <th>position</th>
          <th>position_cat</th>
          <th>market_value</th>
          <th>page_views</th>
          <th>fpl_value</th>
          <th>fpl_sel</th>
          <th>fpl_points</th>
          <th>region</th>
          <th>nationality</th>
          <th>new_foreign</th>
          <th>age_cat</th>
          <th>club_id</th>
          <th>big_club</th>
          <th>new_signing</th>
          <th>Popularity</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Alexis Sanchez</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>LW</td>
          <td>1</td>
          <td>65.0</td>
          <td>4329</td>
          <td>12.0</td>
          <td>17.1</td>
          <td>264</td>
          <td>3</td>
          <td>Chile</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Mesut Ozil</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>AM</td>
          <td>1</td>
          <td>50.0</td>
          <td>4395</td>
          <td>9.5</td>
          <td>5.6</td>
          <td>167</td>
          <td>2</td>
          <td>Germany</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Super Popular</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Petr Cech</td>
          <td>Arsenal</td>
          <td>35</td>
          <td>GK</td>
          <td>4</td>
          <td>7.0</td>
          <td>1529</td>
          <td>5.5</td>
          <td>5.9</td>
          <td>134</td>
          <td>2</td>
          <td>Czech Republic</td>
          <td>0</td>
          <td>6</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Theo Walcott</td>
          <td>Arsenal</td>
          <td>28</td>
          <td>RW</td>
          <td>1</td>
          <td>20.0</td>
          <td>2393</td>
          <td>7.5</td>
          <td>1.5</td>
          <td>122</td>
          <td>1</td>
          <td>England</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Laurent Koscielny</td>
          <td>Arsenal</td>
          <td>31</td>
          <td>CB</td>
          <td>3</td>
          <td>22.0</td>
          <td>912</td>
          <td>6.0</td>
          <td>0.7</td>
          <td>121</td>
          <td>2</td>
          <td>France</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>Popular</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    football.loc[:,['club','name','market_value']][football.position.isin(['GK'])].nlargest(2,'market_value')




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>club</th>
          <th>name</th>
          <th>market_value</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>102</th>
          <td>Chelsea</td>
          <td>Thibaut Courtois</td>
          <td>40.0</td>
        </tr>
        <tr>
          <th>265</th>
          <td>Manchester+United</td>
          <td>David de Gea</td>
          <td>40.0</td>
        </tr>
      </tbody>
    </table>
    </div>


